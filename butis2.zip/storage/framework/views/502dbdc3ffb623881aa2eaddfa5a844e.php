<td <?php echo e($attributes->merge([ 'class' => 'pl-2'])); ?>>
    <?php echo e($slot); ?>

</td><?php /**PATH /mnt/projekte/butis2/resources/views/components/td-list.blade.php ENDPATH**/ ?>