<div class=" px-2 flex border border-gray-400 rounded shadow-lg w-full">
    <ul>
        <?php $__currentLoopData = $stellen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stelle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li x-data="{ open: true }" class="w-full bg-blue-50 px-2 pt-1 ">
                <div class="flex h-5">
                    <div @click="open = ! open" class="cursor-pointer">
                        <?php if($stelle->children->isNotEmpty()): ?>
                            <span x-show="!open">
                                <?php if (isset($component)) { $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c = $attributes; } ?>
<?php $component = BladeUI\Icons\Components\Svg::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('heroicon-s-plus-circle'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\BladeUI\Icons\Components\Svg::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-5 h-5 be_icon_color']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $attributes = $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $component = $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>&nbsp;
                            </span>

                            <span x-show="open">
                                <?php if (isset($component)) { $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c = $attributes; } ?>
<?php $component = BladeUI\Icons\Components\Svg::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('heroicon-o-minus-circle'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\BladeUI\Icons\Components\Svg::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-5 h-5 be_icon_color']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $attributes = $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $component = $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>&nbsp;
                            </span>
                        <?php else: ?>
                            <span class="w-5 h-5">&nbsp;</span>
                        <?php endif; ?>
                    </div>

                    <div class=" lex-grow ml-2 whitespace-nowrap overflow-hidden">

                            <a href="#" wire:click.prevent="triggerEdit(<?php echo e($stelle->id); ?>)" class="hover:underline">
                            <?php echo e($stelle->bezeichnung); ?>


                            </a>
                            - ( <?php echo e($stelle->mitarbeiter->anrede ?? ''); ?> <?php echo e($stelle->mitarbeiter->name ?? 'Kein Mitarbeiter zugeordnet'); ?> )

                    </div>
                </div>

                <?php if($stelle->children->isNotEmpty()): ?>
                    <ul x-show="open" class="ml-4 mb-2">
                        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('stellen-baum', ['parent_id' => $stelle->id]);

$__html = app('livewire')->mount($__name, $__params, $stelle->id, $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                    </ul>
                <?php endif; ?>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>


</div><?php /**PATH /mnt/projekte/butis2/resources/views/livewire/stellen/baum.blade.php ENDPATH**/ ?>