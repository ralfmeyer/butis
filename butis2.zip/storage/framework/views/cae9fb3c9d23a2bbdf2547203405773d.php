<!-- resources/views/emails/example.blade.php -->
<!DOCTYPE html>
<html>
<head>
    <title>Example.blade.php - Beispiel E-Mail</title>
</head>
<body>
    View in der build funktion zugewiesen.
    <h1>title: <?php echo e($details['title']); ?></h1>
    <p>body: <?php echo e($details['body']); ?></p>
</body>
</html>
<?php /**PATH /mnt/projekte/butis2/resources/views/emails/example.blade.php ENDPATH**/ ?>