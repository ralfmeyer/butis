<div class="bg-red-300">

    <ul>
        <?php $__currentLoopData = $stellen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stelle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li x-data="{ open: false }">
                <div @click="open = ! open" class="cursor-pointer">
                    <?php echo e($stelle->bezeichnung); ?> <?php if($stelle->children->isNotEmpty()): ?> > <?php endif; ?>
                </div>

                <?php if($stelle->children->isNotEmpty()): ?>
                    <ul x-show="open" class="ml-4">
                        <?php if(!is_null($stelle)): ?>
                            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('stellen-baum', ['parent_id' => $stelle->id]);

$__html = app('livewire')->mount($__name, $__params, $stelle->id, $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                        <?php endif; ?>
                    </ul>
                <?php endif; ?>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div><?php /**PATH /mnt/projekte/butis2/resources/views/livewire/xstellen-baum.blade.php ENDPATH**/ ?>