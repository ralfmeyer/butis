<div class="">

    <div class="overflow-hidden shadow-2xl ring-2 ring-black ring-opacity-5 rounded-lg bg-blue-50">
        <div class="flex flex-row border border-gray-400 rounded m-2 bg-blue-100 px-2 py-4 text-2xl text-gray-800">
            <?php echo e($kopfueberschrift); ?>

        </div>
        <div class="m-2 border border-gray-500 rounded-lg">
            <table class="w-full">

                <thead class="bg-slate-200 font-bold text-gray-600">
                    <tr>
                        <?php if (isset($component)) { $__componentOriginal5d691fdac3bdc5092b2d493333514ce3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5d691fdac3bdc5092b2d493333514ce3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.th-list','data' => ['class' => '']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('th-list'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => '']); ?>Name <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5d691fdac3bdc5092b2d493333514ce3)): ?>
<?php $attributes = $__attributesOriginal5d691fdac3bdc5092b2d493333514ce3; ?>
<?php unset($__attributesOriginal5d691fdac3bdc5092b2d493333514ce3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5d691fdac3bdc5092b2d493333514ce3)): ?>
<?php $component = $__componentOriginal5d691fdac3bdc5092b2d493333514ce3; ?>
<?php unset($__componentOriginal5d691fdac3bdc5092b2d493333514ce3); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginal5d691fdac3bdc5092b2d493333514ce3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5d691fdac3bdc5092b2d493333514ce3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.th-list','data' => ['class' => '']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('th-list'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => '']); ?>PersonalNr <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5d691fdac3bdc5092b2d493333514ce3)): ?>
<?php $attributes = $__attributesOriginal5d691fdac3bdc5092b2d493333514ce3; ?>
<?php unset($__attributesOriginal5d691fdac3bdc5092b2d493333514ce3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5d691fdac3bdc5092b2d493333514ce3)): ?>
<?php $component = $__componentOriginal5d691fdac3bdc5092b2d493333514ce3; ?>
<?php unset($__componentOriginal5d691fdac3bdc5092b2d493333514ce3); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginal5d691fdac3bdc5092b2d493333514ce3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5d691fdac3bdc5092b2d493333514ce3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.th-list','data' => ['class' => '']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('th-list'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => '']); ?>N-Beurteilung <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5d691fdac3bdc5092b2d493333514ce3)): ?>
<?php $attributes = $__attributesOriginal5d691fdac3bdc5092b2d493333514ce3; ?>
<?php unset($__attributesOriginal5d691fdac3bdc5092b2d493333514ce3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5d691fdac3bdc5092b2d493333514ce3)): ?>
<?php $component = $__componentOriginal5d691fdac3bdc5092b2d493333514ce3; ?>
<?php unset($__componentOriginal5d691fdac3bdc5092b2d493333514ce3); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginal5d691fdac3bdc5092b2d493333514ce3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5d691fdac3bdc5092b2d493333514ce3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.th-list','data' => ['class' => '']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('th-list'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => '']); ?>Bemerkung <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5d691fdac3bdc5092b2d493333514ce3)): ?>
<?php $attributes = $__attributesOriginal5d691fdac3bdc5092b2d493333514ce3; ?>
<?php unset($__attributesOriginal5d691fdac3bdc5092b2d493333514ce3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5d691fdac3bdc5092b2d493333514ce3)): ?>
<?php $component = $__componentOriginal5d691fdac3bdc5092b2d493333514ce3; ?>
<?php unset($__componentOriginal5d691fdac3bdc5092b2d493333514ce3); ?>
<?php endif; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $beurteilungen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $beurteilung): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <?php if (isset($component)) { $__componentOriginalf60970680a21fa732b03369f7e1f30c4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf60970680a21fa732b03369f7e1f30c4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.td-list','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('td-list'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                                <a href="#" wire:click.prevent="edit(<?php echo e($kriterium->id); ?>)">
                                    <?php echo e($beurteilung->name); ?> <?php echo e($beurteilung->vorname); ?>

                                </a>
                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf60970680a21fa732b03369f7e1f30c4)): ?>
<?php $attributes = $__attributesOriginalf60970680a21fa732b03369f7e1f30c4; ?>
<?php unset($__attributesOriginalf60970680a21fa732b03369f7e1f30c4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf60970680a21fa732b03369f7e1f30c4)): ?>
<?php $component = $__componentOriginalf60970680a21fa732b03369f7e1f30c4; ?>
<?php unset($__componentOriginalf60970680a21fa732b03369f7e1f30c4); ?>
<?php endif; ?>
                            <?php if (isset($component)) { $__componentOriginal5d691fdac3bdc5092b2d493333514ce3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5d691fdac3bdc5092b2d493333514ce3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.th-list','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('th-list'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?><?php echo e($beurteilung->personalnr); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5d691fdac3bdc5092b2d493333514ce3)): ?>
<?php $attributes = $__attributesOriginal5d691fdac3bdc5092b2d493333514ce3; ?>
<?php unset($__attributesOriginal5d691fdac3bdc5092b2d493333514ce3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5d691fdac3bdc5092b2d493333514ce3)): ?>
<?php $component = $__componentOriginal5d691fdac3bdc5092b2d493333514ce3; ?>
<?php unset($__componentOriginal5d691fdac3bdc5092b2d493333514ce3); ?>
<?php endif; ?>
                            <?php if (isset($component)) { $__componentOriginalf60970680a21fa732b03369f7e1f30c4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf60970680a21fa732b03369f7e1f30c4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.td-list','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('td-list'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?><?php echo e($beurteilung->nbeurteilung); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf60970680a21fa732b03369f7e1f30c4)): ?>
<?php $attributes = $__attributesOriginalf60970680a21fa732b03369f7e1f30c4; ?>
<?php unset($__attributesOriginalf60970680a21fa732b03369f7e1f30c4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf60970680a21fa732b03369f7e1f30c4)): ?>
<?php $component = $__componentOriginalf60970680a21fa732b03369f7e1f30c4; ?>
<?php unset($__componentOriginalf60970680a21fa732b03369f7e1f30c4); ?>
<?php endif; ?>
                            <?php if (isset($component)) { $__componentOriginalf60970680a21fa732b03369f7e1f30c4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf60970680a21fa732b03369f7e1f30c4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.td-list','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('td-list'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?><?php echo e($beurteilung->bemerkung); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf60970680a21fa732b03369f7e1f30c4)): ?>
<?php $attributes = $__attributesOriginalf60970680a21fa732b03369f7e1f30c4; ?>
<?php unset($__attributesOriginalf60970680a21fa732b03369f7e1f30c4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf60970680a21fa732b03369f7e1f30c4)): ?>
<?php $component = $__componentOriginalf60970680a21fa732b03369f7e1f30c4; ?>
<?php unset($__componentOriginalf60970680a21fa732b03369f7e1f30c4); ?>
<?php endif; ?>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>

            </table>
        </div>
    </div>
        
    

</div><?php /**PATH /mnt/projekte/butis2/resources/views/livewire/beurteilung/listen.blade.php ENDPATH**/ ?>