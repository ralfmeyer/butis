<div>


    <fieldset>
        <legend>Beurteilung vom <?php echo e($datum); ?> f&uuml;r <?php echo e($mitarbeiter->vorname); ?>, <?php echo e($mitarbeiter->name); ?></legend>
    <!--

        {assign bereich ""}

        {if $beurteiler1aktiv}
            {assign beurteiler1 ""}
        {else}
            {assign beurteiler1 "disabled"}
        {/if}

        {if $beurteiler2aktiv}
            {assign beurteiler2 ""}
        {else}
            {assign beurteiler2 "disabled"}
        {/if}





        {assign first true}

-->
        <p>
            Beurteiler1: <?php echo e($beurteiler1->anrede); ?> <?php echo e($beurteiler1->vorname); ?> <?php echo e($beurteiler1->name); ?> - <?php echo e($beurteiler1->stelle); ?> <?php echo e($stelleB1->bezeichnung); ?> <br>
            Beurteiler2: <?php echo e($beurteiler2->anrede); ?> <?php echo e($beurteiler2->vorname); ?> <?php echo e($beurteiler2->name); ?> - <?php echo e($beurteiler2->stelle); ?> <?php echo e($stelleB2->bezeichnung); ?>

        </p>

        <table class="be_show_table">
            <colgroup>
                <col class="be_show_head_col1">
                <col class="be_show_head_col2">
            </colgroup>
            <tr>
                <td class="right" valign="top">
                    <label>Vorname, Name:</label>
                </td>
                <td valign="top">
                    <?php echo e($mitarbeiter->vorname); ?>,  <?php echo e($mitarbeiter->name); ?>

                    <?php if($mitarbeiter->fuehrungskompetenz != true): ?>
                        <br>(ohne F&uuml;hrungsverantwortung)
                    <?php endif; ?>
                </td>
            </tr>

            <tr>
                <td  class="right">
                    <label>Amts-/Dienstbezeichnung:</label>
                </td>
                <td>
                    <?php echo e($beurteilung->stellebeurteilter); ?>

                </td>
            </tr>

            <tr>
                <td class="right">
                    <label>Besoldung:</label>
                </td>
                <td>
                    <?php echo e($mitarbeiter->besoldung); ?>

                </td>
            </tr>
            <tr>
                <td class="right">
                    <label>Beurteilungszeitraum - Datum von:</label><br>
                    <label>Datum bis:</label>
                </td>
                <td>
                    <?php echo e($beurteilung->zeitraumvon); ?><br>
                    <?php echo e($beurteilung->zeitraumbis); ?>

                </td>
            </tr>
            <tr>
                <td class="right" valign="top">
                    <label>Kurze Beschreibung des Aufgabenbereichs:</label>
                </td>
                <td valign="top">
                    <?php echo e($beurteilung->aufgabenbereich); ?>

                </td>
            </tr>
            <tr>
                <td class="right">
                    <label>Beurteilungsart:</label>
                </td>
                <td>
                    <?php if($beurteilung->regelbeurteilung == 1): ?>
                        Regelbeurteilung
                    <?php endif; ?>

                    <?php if($beurteilung->regelbeurteilung == 0): ?>
                            <div  class="text-red-500">Bedarfsbeurteilung</div>
                    <?php endif; ?>

                    <?php if($beurteilung->regelbeurteilung == 2): ?>
                        Probezeitbeurteilung
                            <?php if($beurteilung->beurteilung->beurteilungszeitpunkt == 0): ?>
                                - zur Hälfte
                            <?php endif; ?>
                            <?php if($beurteilung->beurteilung->beurteilungszeitpunkt == 1): ?>
                                - zum Ende
                            <?php endif; ?>
                        <br>Die Beamtin/der Beamte ist auf der Grundlage der Einsch&auml;tzung aus dem beurteilten Abschnitt der Probezeit für die Übernahme in das Beamtenverh&auml;ltnis auf Lebenszeit:<br>
                            <?php if($beurteilung->beurteilung->geeignet2 == 0): ?>
                                Nach heutigem Stand geeignet.
                            <?php else: ?>
                                <?php if($beurteilung->beurteilung->geeignet2 == 1): ?>
                                    Nach heutigem Stand bedingt geeignet.
                                <?php else: ?>
                                    <?php if($beurteilung->beurteilung->geeignet2 == 2): ?>
                                        Nach heutigem Stand nicht geeignet.
                                    <?php endif; ?>
                                <?php endif; ?>
                            <?php endif; ?>
                            <?php if($beurteilung->beurteilung->bemerkung2 != '' && $beurteilung->beurteilungszeitpunkt <> 0): ?>
                                <br>Bemerkung: / Begr&uuml;ndung bei Abweichung von den Werten 80 % und 100%: <?php echo e($beurteilung->bemerkung2); ?>

                            <?php else: ?>
                                <?php if($beurteilung->beurteilung->bemerkung2 != ''): ?>
                                    <br>Bemerkung: <?php echo e($beurteilung->bemerkung2); ?>

                                <?php endif; ?>
                            <?php endif; ?>
                    <?php endif; ?>

                    <?php if($beurteilung->anlass <> ''): ?>
                        Anlass der Beurteilung:<br><?php echo e($beurteilung->anlass); ?>

                    <?php endif; ?>
                </td>
            </tr>
        </table>


        <div>
            <?php if($beurteilung->beurteilungszeitpunkt <> 0): ?>
                    <table class="tabelle_beurteilung" width="100%">
                        <colgroup>
                        <col class="be_show_col1">
                        <col class="be_show_col2">
                        <col class="be_show_col3">
                        </colgroup>
                    <tr class="">
                        <td class="ueberschrift line_bottom" valign="top">
                            <b>Merkmal</b>
                        </td>
                        <td class="ueberschrift line_bottom" valign="top">
                            <b>Note Beurteiler1 <?php echo e($beurteiler1->anrede); ?> <?php echo e($beurteiler1->name); ?></b>
                        </td>
                        <td class="ueberschrift line_bottom" valign="top">
                            <b>Note Beurteiler2 <?php echo e($beurteiler2->anrede); ?> <?php echo e($beurteiler2->name); ?></b>
                        </td>
                    </tr>

                <?php
                    $loc_zaehler = 0;
                ?>

                <?php
                    $loc_bereich = '';
                ?>

                <?php $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <!-- foreach from=$data item=bmerkmal -->


                    <?php if($detail['k']->bereich != $loc_bereich): ?>

                    <a name="<?php echo e($loc_zaehler+1); ?>" ></a>

                    <div id="tab<?php echo e($loc_zaehler+1); ?>">

                        <?php
                            $loc_bereich = $detail['k']->bereich;
                            $loc_zaehler = $loc_zaehler + 1 ;
                        ?>

                    <?php endif; ?>

                    <?php if($mitarbeiter->fuehrungskompetenz != true && (($detail['k']->nummer >= 4 && $detail['k']->nummer <= 5) || ($detail['k']->fuehrungsmerkmal == true ))): ?>
                        <?php
                            $ohnefuehrungskompetenz = 'versteckt';
                        ?>
                    <?php else: ?>
                        <?php
                            $ohnefuehrungskompetenz = '';
                        ?>
                    <?php endif; ?>

                    <tr class="<?php echo e($ohnefuehrungskompetenz); ?>">
                        <td class="">
                            <?php echo e($detail['k']->ueberschrift); ?>

                        </td>
                        <td class="">

                            <?php if($version == 2): ?>
                                <?php if($detail['w']->beurteiler1note==1): ?>
                                <80%
                                <?php endif; ?>
                                <?php if($detail['w']->beurteiler1note==2): ?>
                                80%
                                <?php endif; ?>
                                <?php if($detail['w']->beurteiler1note==3): ?>
                                100%
                                <?php endif; ?>
                                <?php if($detail['w']->beurteiler1note==4): ?>
                                120%
                                <?php endif; ?>

                            <?php else: ?>
                                <?php echo e($detail['w']->beurteiler1note); ?>

                            <?php endif; ?>
                        </td>
                        <td class="">
                            <?php if($version == 2): ?>
                                <?php if($detail['w']->beurteiler2note==1): ?>
                                <80%
                                <?php endif; ?>
                                <?php if($detail['w']->beurteiler2note==2): ?>
                                80%
                                <?php endif; ?>
                                <?php if($detail['w']->beurteiler2note==3): ?>
                                100%
                                <?php endif; ?>
                                <?php if($detail['w']->beurteiler2note==4): ?>
                                120%
                                <?php endif; ?>
                            <?php else: ?>
                                <?php echo e($detail['w']->beurteiler2note); ?>

                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php if($detail['w']->beurteiler1bemerkung != '' || $detail['w']->beurteiler2bemerkung != ''): ?>
                        <tr class="">
                            <td align="right">
                                <?php if($version == 2): ?>
                                    <br>Begr&uuml;ndung:
                                <?php else: ?>
                                    <br>Begr&uuml;ndung bei Abweichung von den Noten 3 und 4:
                                <?php endif; ?>
                            </td>
                            <td>
                                <B>Beurteiler 1:</B><br>
                                <?php echo e($detail['w']->beurteiler1bemerkung); ?>

                            </td>
                            <td>
                                <B>Beurteiler 2:</B><br>
                                <?php echo e($detail['w']->beurteiler2bemerkung); ?>

                            </td>
                        </tr>
                    <?php endif; ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="line_top" align="right">
                            <B>Gesamtnote</B>
                        </td>
                        <td class="line_top">
                            <?php if($version == 2): ?>
                                <?php if($beurteilung->gesamtnote1==1): ?>
                                <80%
                                <?php endif; ?>
                                <?php if($beurteilung->gesamtnote1==2): ?>
                                80%
                                <?php endif; ?>
                                <?php if($beurteilung->gesamtnote1==3): ?>
                                100%
                                <?php endif; ?>
                                <?php if($beurteilung->gesamtnote1==4): ?>
                                120%
                                <?php endif; ?>
                            <?php else: ?>
                                <?php echo e($beurteilung->gesamtnote1); ?>

                            <?php endif; ?>
                        </td>
                        <td class="line_top">
                            <?php if($version == 2): ?>
                                <?php if($beurteilung->gesamtnote2==1): ?>
                                <80%
                                <?php endif; ?>
                                <?php if($beurteilung->gesamtnote2==2): ?>
                                80%
                                <?php endif; ?>
                                <?php if($beurteilung->gesamtnote2==3): ?>
                                100%
                                <?php endif; ?>
                                <?php if($beurteilung->gesamtnote2==4): ?>
                                120%
                                <?php endif; ?>
                            <?php else: ?>
                                <?php echo e($beurteilung->gesamtnote2); ?>

                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <td valign="top" class="line_top" align="right">
                            Begr&uuml;ndung der Gesamtnote:
                        </td>
                        <td valign="top" class="line_top">
                            <?php echo e($beurteilung->gesamtnote1begruendung); ?>

                        </td>
                        <td valign="top" class="line_top">
                            <?php echo e($beurteilung->gesamtnote2begruendung); ?>

                        </td>

                    </tr>
                <?php if( $beurteilung->bemerkung1 != '' || $beurteilung->bemerkung2 != ''): ?>
                    <tr>
                        <td valign="top" class="line_top" align="right">
                            Bemerkung:
                        </td>
                        <td valign="top" class="line_top">
                            <?php echo e($detail['w']->bemerkung1); ?>

                        </td>
                        <td valign="top" class="line_top">
                            <?php echo e($detail['w']->bemerkung2); ?>

                        </td>
                    </tr>
                <?php endif; ?>
                </table>
            <?php endif; ?>
            <?php if($beurteilung->zusatz1 != '' || $beurteilung->zusatz2 != ''): ?>

                <table class="tabelle_beurteilung" width="100%">
                    <tr>
                        <td valign="top" class="line_top" align="right">
                            Zusatzbemerkung:
                        </td>
                        <td  valign="top" class="line_top">
                            <?php echo e($beurteilung->zusatz1); ?>

                        </td>
                        <td  valign="top" class="line_top">
                            <?php echo e($beurteilung->zusatz2); ?>

                        </td>
                    </tr>
                </table>
            <?php endif; ?>


            <div id="tab5">

            </div>
            <div class="nachoben"><a href="#top" title="Nach oben"> <!--  img src="{$this->getImage('up')}" --> </a></div>

        </div>

    <br>
    </fieldset>
    <br>

</div><?php /**PATH /mnt/projekte/butis2/resources/views/livewire/beurteilung/show.blade.php ENDPATH**/ ?>