<div class="w-content m-auto">


    <?php if(session('success')): ?>
    <div
        x-data="{ show: true }"
        x-init="setTimeout(() => show = false, 5000)"
        x-show="show"
        x-transition:enter="transition ease-out duration-500"
        x-transition:enter-start="opacity-0 transform scale-90"
        x-transition:enter-end="opacity-100 transform scale-100"
        x-transition:leave="transition ease-in duration-500"
        x-transition:leave-start="opacity-100 transform scale-100"
        x-transition:leave-end="opacity-0 transform scale-90"
        class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mx-auto mt-4 w-1/2"
        role="alert"
    >
        <span class="block sm:inline"><?php echo e(session('success')); ?></span>
    </div>
<?php endif; ?>


    <div class="be_show_abschnitt">
        <h2 class="be_show_abschnitt_header">
            <span class="text-xs">1.</span> Zur Beurteilung fällige Mitarbeiter als Beurteiler 1
            <span class="text-sm">
                <?php if(count($faelligeMitarbeiterUnterbeurteiler1) == 0): ?> - Keine fälligen Beurteilungen vorhanden. -
                <?php else: ?>
                    ( <?php echo e(count($faelligeMitarbeiterUnterbeurteiler1)); ?> )
                <?php endif; ?>

            </span>
        </h2>
        <?php if(count($faelligeMitarbeiterUnterbeurteiler1) > 0): ?>
            <table class="betable">
                <tr>
                    <th class="be_col1">&nbsp;</th>
                    <th class="be_col2">Name, Vorname</th>
                    <th class="be_col3">Personalnr.</th>
                    <th class="be_col4">N-Beurteilung</th>
                    <th class="be_col5">Bemerkung</th>
                </tr>
                <?php $__currentLoopData = $faelligeMitarbeiterUnterbeurteiler1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mitarbeiter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="be_col1">
                            <a href="<?php echo e(route('beurteilung.create', ['mid' => $mitarbeiter->id])); ?>"
                                class="hover:underline flex justify-end"
                                title="Beurteilung für <?php echo e($mitarbeiter->anrede); ?> <?php echo e($mitarbeiter->name); ?> anlegen.">
                                <?php if (isset($component)) { $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c = $attributes; } ?>
<?php $component = BladeUI\Icons\Components\Svg::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('heroicon-o-document-plus'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\BladeUI\Icons\Components\Svg::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'h-5 be_icon_color']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $attributes = $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $component = $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
                            </a>
                        </td>
                        <td class="be_col2"><?php echo e($mitarbeiter->name); ?> <?php echo e($mitarbeiter->vorname); ?></td>
                        <td class="be_col3"><?php echo e($mitarbeiter->personalnr); ?></td>
                        <td class="be_col4"><?php echo e($mitarbeiter->nbeurteilung); ?></td>
                        <td class="be_col5"><?php echo e($mitarbeiter->bemerkung); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>

        <?php endif; ?>
    </div>

    <div class="be_show_abschnitt">
        <h2 class="be_show_abschnitt_header">
            <span class="text-xs">2.</span> Mitarbeiter mit offenen Beurteilungen als Beurteiler 1
            <span class="text-sm">
                <?php if(count($aktiveBeurteilungenBeurteiler1) == 0): ?> - Keine offenen Beurteilungen vorhanden. -
                <?php else: ?>
                    ( <?php echo e(count($aktiveBeurteilungenBeurteiler1)); ?> )
                <?php endif; ?>
            </span>
        </h2>
        <?php if(count($aktiveBeurteilungenBeurteiler1) > 0): ?>
            <table class="betable">
                <tr>
                    <th class="be_col1">&nbsp;</th>
                    <th class="be_col2">Name, Vorname</th>
                    <th class="be_col3">Personalnr.</th>
                    <th class="be_col4">N-Beurteilung</th>
                    <th class="be_col5">Bemerkung</th>
                </tr>
                <?php $__currentLoopData = $aktiveBeurteilungenBeurteiler1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $beurteilung): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="be_col1">
                            <a href="<?php echo e(route('beurteilung.create', ['mid' => $beurteilung->mMitarbeiter->id])); ?>"
                                class="hover:underline flex justify-end"
                                title="Beurteilung von <?php echo e($mitarbeiter->anrede); ?> <?php echo e($mitarbeiter->name); ?> bearbeiten.">
                                <?php if (isset($component)) { $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c = $attributes; } ?>
<?php $component = BladeUI\Icons\Components\Svg::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('heroicon-o-document-plus'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\BladeUI\Icons\Components\Svg::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'h-5 be_icon_color']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $attributes = $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $component = $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>

                            </a>
                        </td>
                        <td class="be_col2"><?php echo e($beurteilung->mMitarbeiter->name); ?>, <?php echo e($beurteilung->mMitarbeiter->vorname); ?></td>
                        <td class="be_col3"><?php echo e($beurteilung->mMitarbeiter->personalnr); ?></td>
                        <td class="be_col4"><?php echo e($beurteilung->mMitarbeiter->nbeurteilung); ?></td>
                        <td class="be_col4"><?php echo e($beurteilung->mMitarbeiter->bemerkung); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>

    <?php endif; ?>
    </div>

    <div class="be_show_abschnitt">
        <h2 class="be_show_abschnitt_header">
            <span class="text-xs">3.</span> Alle Mitarbeiter in meinem Zuständigkeitsbereich als Beurteiler 1
            <span class="text-sm">
                <?php if(count($mitarbeiterUnterbeurteiler1) == 0): ?> - Keine Mitarbeiter in meinem Zuständigkeitsbereich vorhanden. -
                <?php else: ?>
                ( <?php echo e(count($mitarbeiterUnterbeurteiler1)); ?> )
                <?php endif; ?>
            </span>
        </h2>
        <?php if(count($mitarbeiterUnterbeurteiler1) > 0): ?>
        <table class="betable">
            <colgroup>
                <col class="be_col1">
                <col class="be_col2">
                <col class="be_col3">
                <col class="be_col4">
                <col class="be_col5">
            </colgroup>
            <tr>
                <th class="be_col1">&nbsp;</th>
                <th class="be_col2">Name, Vorname</th>
                <th class="be_col3">Personalnr.</th>
                <th class="be_col4">N-Beurteilung</th>
                <th class="be_col5">Bemerkung</th>
            </tr>
            <?php $__currentLoopData = $mitarbeiterUnterbeurteiler1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mitarbeiter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="be_col1"><?php echo e($mitarbeiter->id); ?></td>
                    <td class="be_col2"><?php echo e($mitarbeiter->name); ?> <?php echo e($mitarbeiter->vorname); ?></td>
                    <td class="be_col3"><?php echo e($mitarbeiter->personalnr); ?></td>
                    <td class="be_col4"><?php echo e($mitarbeiter->nbeurteilung); ?></td>
                    <td class="be_col5"><?php echo e($mitarbeiter->bemerkung); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
        <?php endif; ?>
    </div>

    <div class="be_show_abschnitt">
        <h2 class="be_show_abschnitt_header">
            <span class="text-xs">4.</span> Alle Mitarbeiter in allen Ebenen unter meinem Zuständigkeitsbereich
            <span class="text-sm">
                <?php if(count($mitarbeiterAllerEbenenUnterBeurteiler1) == 0): ?> - Keine Mitarbeiter gefunden. -
                <?php else: ?>
                ( <?php echo e(count($mitarbeiterAllerEbenenUnterBeurteiler1)); ?> )
                <?php endif; ?>
            </span>
        </h2>

        <?php if(count($mitarbeiterAllerEbenenUnterBeurteiler1) > 0): ?>
            <table class="betable">
                <tr>
                    <th class="be_col1">&nbsp;</th>
                    <th class="be_col2">Name, Vorname</th>
                    <th class="be_col3">Personalnr.</th>
                    <th class="be_col4">N-Beurteilung</th>
                    <th class="be_col5">Bemerkung</th>
                </tr>
                <?php $__currentLoopData = $mitarbeiterAllerEbenenUnterBeurteiler1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mitarbeiter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="be_col1">
                            <a href="<?php echo e(route('beurteilung.show', ['id' => $mitarbeiter->getLastBeurteilungID($mitarbeiter->id)])); ?>"
                                class="hover:underline flex justify-end">
                                <?php if (isset($component)) { $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c = $attributes; } ?>
<?php $component = BladeUI\Icons\Components\Svg::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('carbon-document-view'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\BladeUI\Icons\Components\Svg::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'h-5 be_icon_color']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $attributes = $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $component = $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
                            </a>
                        </td>
                        <td class="be_col2"><?php echo e($mitarbeiter->name); ?> <?php echo e($mitarbeiter->vorname); ?></td>
                        <td class="be_col3"><?php echo e($mitarbeiter->personalnr); ?></td>
                        <td class="be_col4"><?php echo e($mitarbeiter->nbeurteilung); ?></td>
                        <td class="be_col5"><?php echo e($mitarbeiter->bemerkung); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        <?php endif; ?>
    </div>

    <!-- REGION Beurteiler 2 -->
    <div class="be_show_abschnitt">
        <h2 class="be_show_abschnitt_header">
            <span class="text-xs">5.</span> Alle Mitarbeiter unter Beurteiler 2 <span class="text-sm">
                <?php if(count($mitarbeiterUnterbeurteiler2) == 0): ?> - Keine Mitarbeiter gefunden. -
                <?php else: ?>
                ( <?php echo e(count($mitarbeiterUnterbeurteiler2)); ?> )
                <?php endif; ?>
            </span>
        </h2>

        <?php if(count($mitarbeiterUnterbeurteiler2) > 0): ?>
            <table class="betable">
                <tr>
                    <th class="be_col1">Id</th>
                    <th class="be_col2">Name, Vorname</th>
                    <th class="be_col3">Personalnr.</th>
                    <th class="be_col4">N-Beurteilung</th>
                    <th class="be_col5">Bemerkung</th>
                </tr>
                <?php $__currentLoopData = $mitarbeiterUnterbeurteiler2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mitarbeiter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="be_col1"><?php echo e($mitarbeiter->id); ?></td>
                        <td class="be_col2"><?php echo e($mitarbeiter->name); ?> <?php echo e($mitarbeiter->vorname); ?></td>
                        <td class="be_col3"><?php echo e($mitarbeiter->personalnr); ?></td>
                        <td class="be_col4"><?php echo e($mitarbeiter->nbeurteilung); ?></td>
                        <td class="be_col5"><?php echo e($mitarbeiter->bemerkung); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        <?php endif; ?>
    </div>

    <div class="be_show_abschnitt">
        <h2 class="be_show_abschnitt_header">
            <span class="text-xs">6.</span> Aktive Beurteilungen von Beurteiler 2

            <span class="text-sm">
                <?php if(count($aktiveBeurteilungenBeurteiler2)  == 0): ?> - Keine aktiven Beurteilungen vorhanden. -
                <?php else: ?>
                ( <?php echo e(count($aktiveBeurteilungenBeurteiler2)); ?> )
                <?php endif; ?>
            </span>
        </h2>
            <?php if(count($aktiveBeurteilungenBeurteiler2) > 0): ?>
                <table class="betable">
                    <tr>
                        <th class="be_col1">&nbsp;</th>
                        <th class="be_col2">Name, Vorname</th>
                        <th class="be_col3">Personalnr.</th>
                        <th class="be_col4">N-Beurteilung</th>
                        <th class="be_col5">Bemerkung</th>
                    </tr>
                    <?php $__currentLoopData = $aktiveBeurteilungenBeurteiler2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $beurteilung): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="be_col1"><?php echo e($beurteilung->id); ?></td>
                            <td class="be_col2"><?php echo e($beurteilung->mitarbeiterid); ?></td>
                            <td class="be_col3"><?php echo e($beurteilung->beurteiler1); ?></td>
                            <td class="be_col4"><?php echo e($beurteilung->beurteiler2); ?></td>
                            <td class="be_col5"><?php echo e($beurteilung->datum); ?></td> <!-- Hier war der Fehler -->
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            <?php endif; ?>
        </h2> <!-- Dieses schließende Tag war an der falschen Stelle -->
    </div>
</div><?php /**PATH /mnt/projekte/butis2/resources/views/livewire/beurteilung/index.blade.php ENDPATH**/ ?>