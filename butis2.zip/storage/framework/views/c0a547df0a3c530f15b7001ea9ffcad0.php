<th <?php echo e($attributes->merge([ 'class' => 'pl-2 pb-2 text-left'])); ?>>
    <?php echo e($slot); ?>

</th><?php /**PATH /mnt/projekte/butis2/resources/views/components/th-list.blade.php ENDPATH**/ ?>