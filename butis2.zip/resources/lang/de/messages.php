<?php

return [
    'Login' => 'Anmeldung',
    'Remember me' => 'Einstellungen merken',
    'Impressum' => 'imprint.messages',
    'Delete Account' => 'Konto löschen',
    // Füge hier weitere allgemeine Übersetzungen hinzu
];
