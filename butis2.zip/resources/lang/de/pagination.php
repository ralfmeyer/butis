<?php

return [
    'previous' => '&laquo; Zurück',
    'next' => 'Weiter &raquo;',
    'Showing ' => 'zeigey',
    'showing ' => 'zeigex',
    'results' => 'Ergebnisse',
    'of' => 'von',
    'debug' => 'debuchtgdsfasdfad'
];
