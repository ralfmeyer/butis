<?php

return [
    'failed' => 'Diese Anmeldedaten stimmen nicht mit unseren Aufzeichnungen überein.',
    'password' => 'Das angegebene Passwort ist falsch.',
    'throttle' => 'Zu viele Anmeldeversuche. Bitte versuche es in :seconds Sekunden erneut.',
    'Remember me' => 'Einstellungen merken',
    'Login' => 'Anmeldung',
    'Password' => 'Passwort',
    'impressum' => 'imprint.auth',
    'Impressum' => 'Impressum',
    'Forgot your password?' => 'Kennwort vergessen?',
    'Log in' => 'ANMELDEN',
    'Delete Account' => 'Konto löschen',
    'personalnr' => 'Personalnummer',
];
