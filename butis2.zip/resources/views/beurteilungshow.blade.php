<x-app-layout>

    @livewire('beurteilung-show', ['id' => $id])

</x-app-layout>
