<x-app-layout>
    @livewire( 'stelle-listen')
</x-app-layout>


