<x-app-layout>
    @livewire( 'mitarbeiter-listen')
</x-app-layout>


