<div>


    <fieldset>
        <legend>Beurteilung vom {{ $datum }} f&uuml;r {{ $mitarbeiter->vorname }}, {{ $mitarbeiter->name }}</legend>
    <!--

        {assign bereich ""}

        {if $beurteiler1aktiv}
            {assign beurteiler1 ""}
        {else}
            {assign beurteiler1 "disabled"}
        {/if}

        {if $beurteiler2aktiv}
            {assign beurteiler2 ""}
        {else}
            {assign beurteiler2 "disabled"}
        {/if}





        {assign first true}

-->
        <p>
            Beurteiler1: {{ $beurteiler1->anrede }} {{ $beurteiler1->vorname }} {{ $beurteiler1->name }} - {{ $beurteiler1->stelle }} {{ $stelleB1->bezeichnung }} <br>
            Beurteiler2: {{ $beurteiler2->anrede }} {{ $beurteiler2->vorname }} {{ $beurteiler2->name }} - {{ $beurteiler2->stelle }} {{ $stelleB2->bezeichnung }}
        </p>

        <table class="be_show_table">
            <colgroup>
                <col class="be_show_head_col1">
                <col class="be_show_head_col2">
            </colgroup>
            <tr>
                <td class="right" valign="top">
                    <label>Vorname, Name:</label>
                </td>
                <td valign="top">
                    {{ $mitarbeiter->vorname }},  {{ $mitarbeiter->name }}
                    @if ($mitarbeiter->fuehrungskompetenz != true)
                        <br>(ohne F&uuml;hrungsverantwortung)
                    @endif
                </td>
            </tr>

            <tr>
                <td  class="right">
                    <label>Amts-/Dienstbezeichnung:</label>
                </td>
                <td>
                    {{ $beurteilung->stellebeurteilter }}
                </td>
            </tr>

            <tr>
                <td class="right">
                    <label>Besoldung:</label>
                </td>
                <td>
                    {{ $mitarbeiter->besoldung }}
                </td>
            </tr>
            <tr>
                <td class="right">
                    <label>Beurteilungszeitraum - Datum von:</label><br>
                    <label>Datum bis:</label>
                </td>
                <td>
                    {{ $beurteilung->zeitraumvon }}<br>
                    {{ $beurteilung->zeitraumbis }}
                </td>
            </tr>
            <tr>
                <td class="right" valign="top">
                    <label>Kurze Beschreibung des Aufgabenbereichs:</label>
                </td>
                <td valign="top">
                    {{ $beurteilung->aufgabenbereich }}
                </td>
            </tr>
            <tr>
                <td class="right">
                    <label>Beurteilungsart:</label>
                </td>
                <td>
                    @if ($beurteilung->regelbeurteilung == 1)
                        Regelbeurteilung
                    @endif

                    @if ($beurteilung->regelbeurteilung == 0)
                            <div  class="text-red-500">Bedarfsbeurteilung</div>
                    @endif

                    @if ($beurteilung->regelbeurteilung == 2)
                        Probezeitbeurteilung
                            @if ($beurteilung->beurteilung->beurteilungszeitpunkt == 0)
                                - zur Hälfte
                            @endif
                            @if ($beurteilung->beurteilung->beurteilungszeitpunkt == 1)
                                - zum Ende
                            @endif
                        <br>Die Beamtin/der Beamte ist auf der Grundlage der Einsch&auml;tzung aus dem beurteilten Abschnitt der Probezeit für die Übernahme in das Beamtenverh&auml;ltnis auf Lebenszeit:<br>
                            @if ($beurteilung->beurteilung->geeignet2 == 0)
                                Nach heutigem Stand geeignet.
                            @else
                                @if ($beurteilung->beurteilung->geeignet2 == 1)
                                    Nach heutigem Stand bedingt geeignet.
                                @else
                                    @if ($beurteilung->beurteilung->geeignet2 == 2)
                                        Nach heutigem Stand nicht geeignet.
                                    @endif
                                @endif
                            @endif
                            @if ($beurteilung->beurteilung->bemerkung2 != '' && $beurteilung->beurteilungszeitpunkt <> 0)
                                <br>Bemerkung: / Begr&uuml;ndung bei Abweichung von den Werten 80 % und 100%: {{ $beurteilung->bemerkung2 }}
                            @else
                                @if ($beurteilung->beurteilung->bemerkung2 != '')
                                    <br>Bemerkung: {{ $beurteilung->bemerkung2 }}
                                @endif
                            @endif
                    @endif

                    @if ($beurteilung->anlass <> '')
                        Anlass der Beurteilung:<br>{{ $beurteilung->anlass }}
                    @endif
                </td>
            </tr>
        </table>


        <div>
            @if ($beurteilung->beurteilungszeitpunkt <> 0)
                    <table class="tabelle_beurteilung" width="100%">
                        <colgroup>
                        <col class="be_show_col1">
                        <col class="be_show_col2">
                        <col class="be_show_col3">
                        </colgroup>
                    <tr class="">
                        <td class="ueberschrift line_bottom" valign="top">
                            <b>Merkmal</b>
                        </td>
                        <td class="ueberschrift line_bottom" valign="top">
                            <b>Note Beurteiler1 {{ $beurteiler1->anrede }} {{ $beurteiler1->name }}</b>
                        </td>
                        <td class="ueberschrift line_bottom" valign="top">
                            <b>Note Beurteiler2 {{ $beurteiler2->anrede }} {{ $beurteiler2->name }}</b>
                        </td>
                    </tr>

                @php
                    $loc_zaehler = 0;
                @endphp

                @php
                    $loc_bereich = '';
                @endphp

                @foreach ($details as $detail)
                    <!-- foreach from=$data item=bmerkmal -->


                    @if ($detail['k']->bereich != $loc_bereich)

                    <a name="{{ $loc_zaehler+1 }}" ></a>

                    <div id="tab{{ $loc_zaehler+1 }}">

                        @php
                            $loc_bereich = $detail['k']->bereich;
                            $loc_zaehler = $loc_zaehler + 1 ;
                        @endphp

                    @endif

                    @if ($mitarbeiter->fuehrungskompetenz != true && (($detail['k']->nummer >= 4 && $detail['k']->nummer <= 5) || ($detail['k']->fuehrungsmerkmal == true )))
                        @php
                            $ohnefuehrungskompetenz = 'versteckt';
                        @endphp
                    @else
                        @php
                            $ohnefuehrungskompetenz = '';
                        @endphp
                    @endif

                    <tr class="{{ $ohnefuehrungskompetenz }}">
                        <td class="">
                            {{ $detail['k']->ueberschrift }}
                        </td>
                        <td class="">

                            @if ($version == 2)
                                @if ($detail['w']->beurteiler1note==1)
                                <80%
                                @endif
                                @if ($detail['w']->beurteiler1note==2)
                                80%
                                @endif
                                @if ($detail['w']->beurteiler1note==3)
                                100%
                                @endif
                                @if ($detail['w']->beurteiler1note==4)
                                120%
                                @endif

                            @else
                                {{ $detail['w']->beurteiler1note }}
                            @endif
                        </td>
                        <td class="">
                            @if ($version == 2)
                                @if ($detail['w']->beurteiler2note==1)
                                <80%
                                @endif
                                @if ($detail['w']->beurteiler2note==2)
                                80%
                                @endif
                                @if ($detail['w']->beurteiler2note==3)
                                100%
                                @endif
                                @if ($detail['w']->beurteiler2note==4)
                                120%
                                @endif
                            @else
                                {{ $detail['w']->beurteiler2note }}
                            @endif
                        </td>
                    </tr>
                    @if ($detail['w']->beurteiler1bemerkung != '' || $detail['w']->beurteiler2bemerkung != '')
                        <tr class="">
                            <td align="right">
                                @if ($version == 2)
                                    <br>Begr&uuml;ndung:
                                @else
                                    <br>Begr&uuml;ndung bei Abweichung von den Noten 3 und 4:
                                @endif
                            </td>
                            <td>
                                <B>Beurteiler 1:</B><br>
                                {{ $detail['w']->beurteiler1bemerkung }}
                            </td>
                            <td>
                                <B>Beurteiler 2:</B><br>
                                {{ $detail['w']->beurteiler2bemerkung }}
                            </td>
                        </tr>
                    @endif

                @endforeach
                    <tr>
                        <td class="line_top" align="right">
                            <B>Gesamtnote</B>
                        </td>
                        <td class="line_top">
                            @if ($version == 2)
                                @if ($beurteilung->gesamtnote1==1)
                                <80%
                                @endif
                                @if ($beurteilung->gesamtnote1==2)
                                80%
                                @endif
                                @if ($beurteilung->gesamtnote1==3)
                                100%
                                @endif
                                @if ($beurteilung->gesamtnote1==4)
                                120%
                                @endif
                            @else
                                {{ $beurteilung->gesamtnote1 }}
                            @endif
                        </td>
                        <td class="line_top">
                            @if ($version == 2)
                                @if ($beurteilung->gesamtnote2==1)
                                <80%
                                @endif
                                @if ($beurteilung->gesamtnote2==2)
                                80%
                                @endif
                                @if ($beurteilung->gesamtnote2==3)
                                100%
                                @endif
                                @if ($beurteilung->gesamtnote2==4)
                                120%
                                @endif
                            @else
                                {{ $beurteilung->gesamtnote2 }}
                            @endif
                        </td>
                    </tr>
                    <tr>
                        <td valign="top" class="line_top" align="right">
                            Begr&uuml;ndung der Gesamtnote:
                        </td>
                        <td valign="top" class="line_top">
                            {{ $beurteilung->gesamtnote1begruendung }}
                        </td>
                        <td valign="top" class="line_top">
                            {{ $beurteilung->gesamtnote2begruendung }}
                        </td>

                    </tr>
                @if ( $beurteilung->bemerkung1 != '' || $beurteilung->bemerkung2 != '')
                    <tr>
                        <td valign="top" class="line_top" align="right">
                            Bemerkung:
                        </td>
                        <td valign="top" class="line_top">
                            {{ $detail['w']->bemerkung1 }}
                        </td>
                        <td valign="top" class="line_top">
                            {{ $detail['w']->bemerkung2 }}
                        </td>
                    </tr>
                @endif
                </table>
            @endif
            @if ($beurteilung->zusatz1 != '' || $beurteilung->zusatz2 != '')

                <table class="tabelle_beurteilung" width="100%">
                    <tr>
                        <td valign="top" class="line_top" align="right">
                            Zusatzbemerkung:
                        </td>
                        <td  valign="top" class="line_top">
                            {{ $beurteilung->zusatz1 }}
                        </td>
                        <td  valign="top" class="line_top">
                            {{ $beurteilung->zusatz2 }}
                        </td>
                    </tr>
                </table>
            @endif


            <div id="tab5">

            </div>
            <div class="nachoben"><a href="#top" title="Nach oben"> <!--  img src="{$this->getImage('up')}" --> </a></div>

        </div>

    <br>
    </fieldset>
    <br>

</div>
