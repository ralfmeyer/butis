<x-app-layout>
    {{-- @livewire( 'beurteilung-listen') --}}
    @livewire('beurteilung-index')

</x-app-layout>
