<x-app-layout>

    @livewire('beurteilung-create', ['mid' => $mid])

</x-app-layout>
