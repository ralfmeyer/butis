<!-- resources/views/emails/example.blade.php -->
<!DOCTYPE html>
<html>
<head>
    <title>Example.blade.php - Beispiel E-Mail</title>
</head>
<body>
    View in der build funktion zugewiesen.
    <h1>title: {{ $details['title'] }}</h1>
    <p>body: {{ $details['body'] }}</p>
</body>
</html>
