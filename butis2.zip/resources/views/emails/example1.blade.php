<!-- resources/views/emails/example.blade.php -->
<!DOCTYPE html>
<html>
<head>
    <title>Example1.blade.php - Beispiel E-Mail</title>
</head>
<body>
    View in der content funktion zugewiesen.

    <h1>title: {{ $details['title'] }}</h1>
    <p>body: {{ $details['body'] }}</p>
</body>
</html>
