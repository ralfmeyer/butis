<x-app-layout>
    @livewire( 'kriterien-listen')
</x-app-layout>
