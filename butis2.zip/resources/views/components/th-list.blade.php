<th {{ $attributes->merge([ 'class' => 'pl-2 pb-2 text-left']) }}>
    {{ $slot }}
</th>