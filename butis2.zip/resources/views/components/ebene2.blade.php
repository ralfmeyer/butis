<svg xmlns="http://www.w3.org/2000/svg" xml:space="preserve" width="35mm" height="12.5mm" version="1.1" style="shape-rendering:geometricPrecision; text-rendering:geometricPrecision; image-rendering:optimizeQuality; fill-rule:evenodd; clip-rule:evenodd"
viewBox="0 0 12235.8 4369.9"
 xmlns:xlink="http://www.w3.org/1999/xlink"
 xmlns:xodm="http://www.corel.com/coreldraw/odm/2003">
 <defs>
  <style type="text/css">
   <![CDATA[
    .str0 {stroke:#2B2A29;stroke-width:123.3;stroke-miterlimit:22.9256}
    .fil0 {fill:none}
   ]]>
  </style>
 </defs>
 <g id="Ebene_x0020_1">
  <metadata id="CorelCorpID_0Corel-Layer"/>
  <rect class="fil0" x="-0" y="0" width="12235.8" height="4369.9"/>
  <polyline class="fil0 str0" points="3496,0 3496,2605.6 12235.8,2605.6 "/>
  <line class="fil0 str0" x1="3496" y1="1471" x2="3496" y2= "4369.9" />
  <line class="fil0 str0" x1="1748" y1="0" x2="1748" y2= "4369.9" />
 </g>
</svg>