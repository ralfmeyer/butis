<td {{ $attributes->merge([ 'class' => 'pl-2']) }}>
    {{ $slot }}
</td>