<?PHP
	phpinfo();
?>
